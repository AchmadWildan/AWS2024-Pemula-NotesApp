/* eslint-disable linebreak-style */
const books = [];

module.exports = books;